import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  Box,
  VStack,
  Text,
  useColorMode,
  Icon,
  Image,
} from '@chakra-ui/react';
import {
  MdDashboard,
  MdPeople,
  MdQueue,
  MdCheckCircle,
  MdPerson,
} from 'react-icons/md';
import logo from '../assets/logo.png';

function Sidebar() {
  const { colorMode } = useColorMode();

  const navLinkStyles = ({ isActive }) => ({
    display: 'flex',
    alignItems: 'center',
    px: 6,
    py: 2,
    borderRadius: '12px',
    bg: isActive
      ? 'brand.500'
      : colorMode === 'light'
      ? 'transparent'
      : 'transparent',
    color: isActive
      ? 'white'
      : colorMode === 'light'
      ? 'gray.800'
      : 'gray.200',
    _hover: {
      bg: isActive ? 'brand.600' : '#f05122',
    },
  });

  return (
    <Box
      position="fixed"
      left={0}
      top={0}
      h="100vh"
      w={{ base: '250px', md: '250px' }}
      bg={colorMode === 'light' ? 'white' : 'gray.800'}
      borderRadius="0 30px 30px 0"
      shadow="lg"
      display={{ base: 'none', md: 'block' }}
      zIndex={10}
    >
      <Box px={6} py={4}>
        <Image src={logo} alt="Penguan Logo" width="150px" />
      </Box>
      <VStack spacing={2} align="stretch" mt={4} px={3}>
        <NavLink to="/dashboard" style={navLinkStyles}>
          <Icon as={MdDashboard} mr={3} boxSize={6} />
          <Text fontSize="md" fontWeight="bold">Dashboard</Text>
        </NavLink>
        <NavLink to="/staff" style={navLinkStyles}>
          <Icon as={MdPeople} mr={3} boxSize={6} />
          <Text fontSize="md" fontWeight="bold">Staff</Text>
        </NavLink>
        <NavLink to="/queues" style={navLinkStyles}>
          <Icon as={MdQueue} mr={3} boxSize={6} />
          <Text fontSize="md" fontWeight="bold">Queues</Text>
        </NavLink>
        <NavLink to="/checkins" style={navLinkStyles}>
          <Icon as={MdCheckCircle} mr={3} boxSize={6} />
          <Text fontSize="md" fontWeight="bold">Check-Ins</Text>
        </NavLink>
        <NavLink to="/users" style={navLinkStyles}>
          <Icon as={MdPerson} mr={3} boxSize={6} />
          <Text fontSize="md" fontWeight="bold">Users</Text>
        </NavLink>
      </VStack>
    </Box>
  );
}

export default Sidebar;