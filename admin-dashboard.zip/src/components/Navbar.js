import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Flex,
  Heading,
  IconButton,
  Button,
  useColorMode,
  Icon,
} from '@chakra-ui/react';
import { MoonIcon, SunIcon, HamburgerIcon } from '@chakra-ui/icons';

function Navbar({ title, toggleSidebar }) {
  const { colorMode, toggleColorMode } = useColorMode();
  const navigate = useNavigate();

  // Add console log to debug rendering
  useEffect(() => {
    console.log(`Navbar rendered for ${title} page at ${new Date().toISOString()}`);
  }, [title]);

  const handleSignOut = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <Box
      bg={colorMode === 'light' ? 'gray.50' : 'gray.800'}
      borderBottom="1px solid"
      borderColor={colorMode === 'light' ? 'gray.200' : 'gray.600'}
      px={6}
      py={4}
      position="sticky"
      top={0}
      zIndex={10}
    >
      <Flex justify="space-between" align="center">
        <Flex align="center" gap={4}>
          <IconButton
            aria-label="Toggle sidebar"
            icon={<HamburgerIcon />}
            onClick={toggleSidebar}
            colorScheme="brand"
            borderRadius="12px"
            display={{ base: 'flex', md: 'none' }}
          />
          <Heading
            size="lg"
            color={colorMode === 'light' ? 'gray.800' : 'white'}
          >
            {title}
          </Heading>
        </Flex>
        <Flex align="center" gap={4}>
          <IconButton
            aria-label="Toggle color mode"
            icon={colorMode === 'light' ? <MoonIcon /> : <SunIcon />}
            onClick={toggleColorMode}
            colorScheme="brand"
            borderRadius="12px"
          />
          <Button
            colorScheme="red"
            borderRadius="12px"
            size="md"
            _hover={{ transform: 'translateY(-2px)', shadow: 'md' }}
            onClick={handleSignOut}
          >
            Sign Out
          </Button>
        </Flex>
      </Flex>
    </Box>
  );
}

export default Navbar;