import React from 'react';
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Button,
  FormControl,
  FormLabel,
  Input,
} from '@chakra-ui/react';

function UserForm({ isOpen, onClose, user, onSubmit }) {
  const [formData, setFormData] = React.useState({
    phone: user?.phone || '',
    name: user?.name || '',
    rewardPoints: user?.rewardPoints || 0,
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    onSubmit(formData);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>{user ? 'Edit User' : 'Create User'}</ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          <FormControl mb="4">
            <FormLabel>Phone Number</FormLabel>
            <Input
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="Enter phone number"
            />
          </FormControl>
          <FormControl mb="4">
            <FormLabel>Name</FormLabel>
            <Input
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter name"
            />
          </FormControl>
          <FormControl mb="4">
            <FormLabel>Reward Points</FormLabel>
            <Input
              type="number"
              name="rewardPoints"
              value={formData.rewardPoints}
              onChange={handleChange}
              placeholder="Enter reward points"
            />
          </FormControl>
        </ModalBody>
        <ModalFooter>
          <Button colorScheme="primary" mr="3" onClick={handleSubmit}>Save
          </Button>
          <Button onClick={onClose}>Cancel</Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}

export default UserForm;