import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Button,
  FormControl,
  FormLabel,
  Input,
  Select,
} from '@chakra-ui/react';

function StaffForm({ isOpen, onClose, staff, onSubmit }) {
  const [formData, setFormData] = useState({ name: '', email: '', assignedQueues: [] });
  const [queues, setQueues] = useState([]);

  // Fetch queues when the modal opens
  useEffect(() => {
    const fetchQueues = async () => {
      const token = localStorage.getItem('token');
      const config = { headers: { 'x-auth-token': token } };
      try {
        const res = await axios.get('http://localhost:5000/api/queue', config);
        setQueues(res.data);
      } catch (error) {
        console.error('Error fetching queues:', error);
      }
    };
    if (isOpen) {
      fetchQueues();
    }
  }, [isOpen]);

  // Populate form data when editing a staff member
  useEffect(() => {
    if (staff) {
      setFormData({
        name: staff.name,
        email: staff.email || '',
        assignedQueues: staff.assignedQueues ? staff.assignedQueues.map(queue => queue._id) : [],
      });
    } else {
      setFormData({ name: '', email: '', assignedQueues: [] });
    }
  }, [staff, isOpen]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'assignedQueues') {
      // Convert selected options to an array of queue IDs
      const selectedQueues = Array.from(e.target.selectedOptions, (option) => option.value);
      setFormData({ ...formData, assignedQueues: selectedQueues });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = () => {
    onSubmit(formData);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>{staff ? 'Edit Staff' : 'Create Staff'}</ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          <FormControl mb="4">
            <FormLabel>Name</FormLabel>
            <Input
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter staff name"
            />
          </FormControl>
          <FormControl mb="4">
            <FormLabel>Email</FormLabel>
            <Input
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter email"
              type="email"
            />
          </FormControl>
          <FormControl mb="4">
            <FormLabel>Assign Queues</FormLabel>
            <Select
              name="assignedQueues"
              value={formData.assignedQueues}
              onChange={handleChange}
              placeholder="Select queues"
              multiple
              height="100px" // Allow multiple selections to be visible
            >
              {queues.map((queue) => (
                <option key={queue._id} value={queue._id}>
                  {queue.name}
                </option>
              ))}
            </Select>
          </FormControl>
        </ModalBody>
        <ModalFooter>
          <Button colorScheme="primary" mr="3" onClick={handleSubmit}>
            Save
          </Button>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}

export default StaffForm;