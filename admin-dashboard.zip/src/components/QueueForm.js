import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Button,
  FormControl,
  FormLabel,
  Input,
  Select,
} from '@chakra-ui/react';

function QueueForm({ isOpen, onClose, queue, onSubmit }) {
  const [formData, setFormData] = useState({ name: '', estimatedTime: '', assignedStaff: [] });
  const [staffMembers, setStaffMembers] = useState([]);

  // Fetch staff members when the modal opens
  useEffect(() => {
    const fetchStaff = async () => {
      const token = localStorage.getItem('token');
      const config = { headers: { 'x-auth-token': token } };
      try {
        const res = await axios.get('http://localhost:5000/api/staff', config);
        setStaffMembers(res.data);
      } catch (error) {
        console.error('Error fetching staff:', error);
      }
    };
    if (isOpen) {
      fetchStaff();
    }
  }, [isOpen]);

  // Populate form data when editing a queue
  useEffect(() => {
    if (queue) {
      setFormData({
        name: queue.name,
        estimatedTime: queue.estimatedTime || '',
        assignedStaff: queue.assignedStaff || [],
      });
    } else {
      setFormData({ name: '', estimatedTime: '', assignedStaff: [] });
    }
  }, [queue, isOpen]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'assignedStaff') {
      // Convert selected options to an array of staff IDs
      const selectedStaff = Array.from(e.target.selectedOptions, (option) => option.value);
      setFormData({ ...formData, assignedStaff: selectedStaff });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = () => {
    // Convert estimatedTime to a number before submitting
    const submitData = {
      ...formData,
      estimatedTime: formData.estimatedTime ? Number(formData.estimatedTime) : undefined,
    };
    onSubmit(submitData);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>{queue ? 'Edit Queue' : 'Create Queue'}</ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          <FormControl mb="4">
            <FormLabel>Name</FormLabel>
            <Input
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter queue name"
            />
          </FormControl>
          <FormControl mb="4">
            <FormLabel>Estimated Time (minutes)</FormLabel>
            <Input
              name="estimatedTime"
              value={formData.estimatedTime}
              onChange={handleChange}
              placeholder="Enter estimated time in minutes"
              type="number"
            />
          </FormControl>
          <FormControl mb="4">
            <FormLabel>Assign Staff</FormLabel>
            <Select
              name="assignedStaff"
              value={formData.assignedStaff}
              onChange={handleChange}
              placeholder="Select staff members"
              multiple
              height="100px" // Allow multiple selections to be visible
            >
              {staffMembers.map((staff) => (
                <option key={staff._id} value={staff._id}>
                  {staff.name}
                </option>
              ))}
            </Select>
          </FormControl>
        </ModalBody>
        <ModalFooter>
          <Button colorScheme="primary" mr="3" onClick={handleSubmit}>
            Save
          </Button>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}

export default QueueForm;