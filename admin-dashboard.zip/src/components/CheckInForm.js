import React from 'react';
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Button,
  FormControl,
  FormLabel,
  Input,
} from '@chakra-ui/react';

function CheckInForm({ isOpen, onClose, checkIn, onSubmit }) {
  const [rewardPointsEarned, setRewardPointsEarned] = React.useState(
    checkIn?.rewardPointsEarned || 10
  );

  const handleSubmit = () => {
    onSubmit({ rewardPointsEarned: parseInt(rewardPointsEarned) });
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Edit Check-In</ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          <FormControl mb="4">
            <FormLabel>Reward Points Earned</FormLabel>
            <Input
              type="number"
              value={rewardPointsEarned}
              onChange={(e) => setRewardPointsEarned(e.target.value)}
              placeholder="Enter reward points earned"
            />
          </FormControl>
        </ModalBody>
        <ModalFooter>
          <Button colorScheme="primary" mr="3" onClick={handleSubmit}>Save
          </Button>
          <Button onClick={onClose}>Cancel</Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}

export default CheckInForm;