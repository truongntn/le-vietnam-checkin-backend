import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom'; // Import useLocation
import axios from 'axios';
import {
  Box,
  Button,
  Flex,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Card,
  CardBody,
  useDisclosure,
} from '@chakra-ui/react';
import Sidebar from '../components/Sidebar';
import Navbar from '../components/Navbar';
import UserForm from '../components/UserForm';

function User() {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const location = useLocation(); // Use useLocation to detect route changes

  const fetchUsers = async () => {
    const token = localStorage.getItem('token');
    const config = { headers: { 'x-auth-token': token } };
    try {
      const res = await axios.get('http://localhost:5000/api/users', config);
      console.log('Fetched users data:', res.data);
      setUsers(res.data);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Reset Sidebar state on route change
  useEffect(() => {
    setIsSidebarOpen(false); // Close Sidebar when the route changes
  }, [location.pathname]);

  const handleCreate = async (data) => {
    const token = localStorage.getItem('token');
    const config = { headers: { 'x-auth-token': token } };
    try {
      await axios.post('http://localhost:5000/api/users', data, config);
      await fetchUsers();
    } catch (error) {
      console.error('Error creating user:', error);
    }
  };

  const handleEdit = async (data) => {
    const token = localStorage.getItem('token');
    const config = { headers: { 'x-auth-token': token } };
    try {
      await axios.put(`http://localhost:5000/api/users/${selectedUser._id}`, data, config);
      await fetchUsers();
    } catch (error) {
      console.error('Error editing user:', error);
    }
  };

  const handleDelete = async (id) => {
    const token = localStorage.getItem('token');
    const config = { headers: { 'x-auth-token': token } };
    try {
      await axios.delete(`http://localhost:5000/api/users/${id}`, config);
      await fetchUsers();
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <Flex h="100vh" direction={{ base: 'column', md: 'row' }}>
      <Box
        display={{
          base: isSidebarOpen ? 'block' : 'none',
          md: 'block',
        }}
        position={{ base: 'absolute', md: 'fixed' }}
        zIndex={20}
        w={{ base: '250px', md: '250px' }}
        h={{ base: '100vh', md: '100vh' }}
      >
        <Sidebar />
      </Box>
      <Box
        flex="1"
        overflowY="auto"
        ml={{ base: 0, md: '250px' }}
      >
        <Navbar title="Users" toggleSidebar={toggleSidebar} />
        <Box p="6" pt={0}>
          <Box mt={6}>
            <Button
              colorScheme="brand"
              borderRadius="12px"
              size="md"
              _hover={{ transform: 'translateY(-2px)', shadow: 'md' }}
              onClick={() => {
                setSelectedUser(null);
                onOpen();
              }}
            >
              Create User
            </Button>
          </Box>
          <Card
            shadow="lg"
            borderRadius="15px"
            mt={6}
          >
            <CardBody>
              <Table variant="simple" colorScheme="gray">
                <Thead>
                  <Tr>
                    <Th>Name</Th>
                    <Th>Email</Th>
                    <Th>Role</Th>
                    <Th>Actions</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {users.map((user) => (
                    <Tr key={user._id}>
                      <Td>{user.name || '-'}</Td>
                      <Td>{user.email || '-'}</Td>
                      <Td>{user.role || '-'}</Td>
                      <Td>
                        <Button
                          size="sm"
                          colorScheme="brand"
                          borderRadius="12px"
                          mr="2"
                          _hover={{ transform: 'translateY(-2px)', shadow: 'md' }}
                          onClick={() => {
                            setSelectedUser(user);
                            onOpen();
                          }}
                        >
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          colorScheme="red"
                          borderRadius="12px"
                          _hover={{ transform: 'translateY(-2px)', shadow: 'md' }}
                          onClick={() => handleDelete(user._id)}
                        >
                          Delete
                        </Button>
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </CardBody>
          </Card>
          <UserForm
            isOpen={isOpen}
            onClose={onClose}
            user={selectedUser}
            onSubmit={selectedUser ? handleEdit : handleCreate}
          />
        </Box>
      </Box>
    </Flex>
  );
}

export default User;