import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Box,
  Flex,
  SimpleGrid,
  Stat,
  StatLabel,
  StatNumber,
  Card,
  CardBody,
} from '@chakra-ui/react';
import Sidebar from '../components/Sidebar';
import Navbar from '../components/Navbar';

function Dashboard() {
  const [stats, setStats] = useState({
    totalStaff: 0,
    totalQueues: 0,
    totalCheckIns: 0,
  });
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const fetchStats = async () => {
    const token = localStorage.getItem('token');
    const config = { headers: { 'x-auth-token': token } };
    try {
      const [staffRes, queuesRes, checkInsRes] = await Promise.all([
        axios.get('http://localhost:5000/api/staff', config),
        axios.get('http://localhost:5000/api/queue', config),
        axios.get('http://localhost:5000/api/checkin', config),
      ]);
      setStats({
        totalStaff: staffRes.data.length,
        totalQueues: queuesRes.data.length,
        totalCheckIns: checkInsRes.data.length,
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <Flex h="100vh" direction={{ base: 'column', md: 'row' }}>
      <Box
        display={{
          base: isSidebarOpen ? 'block' : 'none',
          md: 'block',
        }}
        position={{ base: 'absolute', md: 'fixed' }}
        zIndex={20}
        w={{ base: '250px', md: '250px' }}
        h={{ base: '100vh', md: '100vh' }}
      >
        <Sidebar />
      </Box>
      <Box
        flex="1"
        overflowY="auto"
        ml={{ base: 0, md: '250px' }}
      >
        <Navbar title="Dashboard" toggleSidebar={toggleSidebar} />
        <Box p="6" pt={0}>
          <SimpleGrid columns={{ base: 1, md: 3 }} spacing={6} mt={6}>
            <Card shadow="lg" borderRadius="15px">
              <CardBody>
                <Stat>
                  <StatLabel fontSize="lg" fontWeight="bold">
                    Total Staff
                  </StatLabel>
                  <StatNumber fontSize="2xl">{stats.totalStaff}</StatNumber>
                </Stat>
              </CardBody>
            </Card>
            <Card shadow="lg" borderRadius="15px">
              <CardBody>
                <Stat>
                  <StatLabel fontSize="lg" fontWeight="bold">
                    Total Queues
                  </StatLabel>
                  <StatNumber fontSize="2xl">{stats.totalQueues}</StatNumber>
                </Stat>
              </CardBody>
            </Card>
            <Card shadow="lg" borderRadius="15px">
              <CardBody>
                <Stat>
                  <StatLabel fontSize="lg" fontWeight="bold">
                    Total Check-Ins
                  </StatLabel>
                  <StatNumber fontSize="2xl">{stats.totalCheckIns}</StatNumber>
                </Stat>
              </CardBody>
            </Card>
          </SimpleGrid>
        </Box>
      </Box>
    </Flex>
  );
}

export default Dashboard;