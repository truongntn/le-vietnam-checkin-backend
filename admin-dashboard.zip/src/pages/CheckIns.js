import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import {
  Box,
  Button,
  Flex,
  useDisclosure,
} from '@chakra-ui/react';
import { Grid } from 'gridjs-react';
import { h } from 'gridjs';
import 'gridjs/dist/theme/mermaid.css'; // Import Grid.js Mermaid theme
import Sidebar from '../components/Sidebar';
import Navbar from '../components/Navbar';
import CheckInForm from '../components/CheckInForm';

function CheckIn() {
  const [checkIns, setCheckIns] = useState([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const location = useLocation();

  const fetchCheckIns = async () => {
    const token = localStorage.getItem('token');
    const config = { headers: { 'x-auth-token': token } };
    try {
      const res = await axios.get('http://localhost:5000/api/checkin', config);
      console.log('Fetched check-ins data:', res.data);
      setCheckIns(res.data);
    } catch (error) {
      console.error('Error fetching check-ins:', error);
    }
  };

  useEffect(() => {
    fetchCheckIns();
  }, []);

  useEffect(() => {
    setIsSidebarOpen(false);
  }, [location.pathname]);

  const handleCreate = async (data) => {
    const token = localStorage.getItem('token');
    const config = { headers: { 'x-auth-token': token } };
    try {
      await axios.post('http://localhost:5000/api/checkin', data, config);
      await fetchCheckIns();
    } catch (error) {
      console.error('Error creating check-in:', error);
    }
  };

  const handleDelete = async (id) => {
    const token = localStorage.getItem('token');
    const config = { headers: { 'x-auth-token': token } };
    try {
      await axios.delete(`http://localhost:5000/api/checkin/${id}`, config);
      await fetchCheckIns();
    } catch (error) {
      console.error('Error deleting check-in:', error);
    }
  };

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // Define Grid.js columns
  const columns = [
    {
      name: 'Name',
      formatter: (cell) => cell || '-',
    },
    {
      name: 'Queue',
      formatter: (cell) => (cell && cell.name ? cell.name : '-'),
      data: (row) => row.queue,
    },
    {
      name: 'Check-In Time',
      formatter: (cell) => (cell ? new Date(cell).toLocaleString() : '-'),
      data: (row) => row.checkInTime,
    },
    {
      name: 'Actions',
      formatter: (_, row) => h(
        'button',
        {
          className: 'gridjs-button gridjs-button--delete',
          onClick: () => handleDelete(row.cells[0].data),
          style: {
            backgroundColor: '#e53e3e', // Red color matching Chakra's red
            color: 'white',
            borderRadius: '12px',
            padding: '4px 12px',
            border: 'none',
            cursor: 'pointer',
            fontSize: '14px',
            transition: 'transform 0.2s, box-shadow 0.2s',
          },
          onMouseEnter: (e) => {
            e.target.style.transform = 'translateY(-2px)';
            e.target.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
          },
          onMouseLeave: (e) => {
            e.target.style.transform = 'translateY(0)';
            e.target.style.boxShadow = 'none';
          },
        },
        'Delete'
      ),
      data: (row) => row._id, // Pass _id for the formatter
    },
  ];

  return (
    <Flex h="100vh" direction={{ base: 'column', md: 'row' }}>
      <Box
        display={{
          base: isSidebarOpen ? 'block' : 'none',
          md: 'block',
        }}
        position={{ base: 'absolute', md: 'fixed' }}
        zIndex={20}
        w={{ base: '250px', md: '250px' }}
        h={{ base: '100vh', md: '100vh' }}
      >
        <Sidebar />
      </Box>
      <Box
        flex="1"
        overflowY="auto"
        ml={{ base: 0, md: '250px' }}
      >
        <Navbar title="Check-Ins" toggleSidebar={toggleSidebar} />
        <Box p="6" pt={0}>
          <Box mt={6}>
            <Button
              colorScheme="brand"
              borderRadius="12px"
              size="md"
              _hover={{ transform: 'translateY(-2px)', shadow: 'md' }}
              onClick={onOpen}
            >
              Create Check-In
            </Button>
          </Box>
          <Box
            mt={6}
            shadow="lg"
            borderRadius="15px"
            overflow="hidden" // Ensure rounded corners apply to Grid.js table
            bg="white" // Background to match Horizon UI card
          >
            <Grid
              data={checkIns}
              columns={columns}
              sort={true} // Enable sorting
              pagination={{
                enabled: true,
                limit: 5, // Show 5 rows per page
              }}
              style={{
                table: {
                  border: 'none',
                },
                th: {
                  backgroundColor: '#f7fafc', // Light gray for header
                  color: '#2d3748', // Darker text for header
                  fontWeight: 'bold',
                  padding: '16px',
                },
                td: {
                  padding: '16px',
                  borderBottom: '1px solid #e2e8f0',
                },
                container: {
                  padding: '16px',
                },
              }}
              className={{
                table: 'w-full',
                pagination: 'mt-4 flex justify-end',
                paginationButton: 'px-3 py-1 mx-1 rounded-lg border',
                paginationButtonCurrent: 'bg-brand.500 text-white',
              }}
            />
          </Box>
          <CheckInForm
            isOpen={isOpen}
            onClose={onClose}
            onSubmit={handleCreate}
          />
        </Box>
      </Box>
    </Flex>
  );
}

export default CheckIn;