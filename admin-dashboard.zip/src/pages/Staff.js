import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import {
  Box,
  Button,
  Flex,
  useDisclosure,
} from '@chakra-ui/react';
import { Grid } from 'gridjs-react';
import { h } from 'gridjs';
import 'gridjs/dist/theme/mermaid.css'; // Import Grid.js Mermaid theme
import Sidebar from '../components/Sidebar';
import Navbar from '../components/Navbar';
import StaffForm from '../components/StaffForm';

function Staff() {
  const [staff, setStaff] = useState([]);
  const [selectedStaff, setSelectedStaff] = useState(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const location = useLocation();

  const fetchStaff = async () => {
    const token = localStorage.getItem('token');
    const config = { headers: { 'x-auth-token': token } };
    try {
      const res = await axios.get('http://localhost:5000/api/staff', config);
      console.log('Fetched staff data:', res.data);
      setStaff(res.data);
    } catch (error) {
      console.error('Error fetching staff:', error);
    }
  };

  useEffect(() => {
    fetchStaff();
  }, []);

  useEffect(() => {
    setIsSidebarOpen(false);
  }, [location.pathname]);

  const handleCreate = async (data) => {
    const token = localStorage.getItem('token');
    const config = { headers: { 'x-auth-token': token } };
    try {
      await axios.post('http://localhost:5000/api/staff', data, config);
      await fetchStaff();
    } catch (error) {
      console.error('Error creating staff:', error);
    }
  };

  const handleEdit = async (data) => {
    const token = localStorage.getItem('token');
    const config = { headers: { 'x-auth-token': token } };
    try {
      await axios.put(`http://localhost:5000/api/staff/${selectedStaff._id}`, data, config);
      await fetchStaff();
    } catch (error) {
      console.error('Error editing staff:', error);
    }
  };

  const handleDelete = async (id) => {
    const token = localStorage.getItem('token');
    const config = { headers: { 'x-auth-token': token } };
    try {
      await axios.delete(`http://localhost:5000/api/staff/${id}`, config);
      await fetchStaff();
    } catch (error) {
      console.error('Error deleting staff:', error);
    }
  };

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // Define Grid.js columns
  const columns = [
    {
      name: 'Name',
      formatter: (cell) => cell || '-',
    },
    {
      name: 'Email',
      formatter: (cell) => cell || '-',
    },
    {
      name: 'Assigned Queues',
      formatter: (cell) =>
        cell && cell.length > 0 ? cell.map((queue) => queue.name).join(', ') : '-',
      data: (row) => row.assignedQueues,
    },
    {
      name: 'Actions',
      formatter: (_, row) => h(
        'div',
        { className: 'gridjs-actions', style: { display: 'flex', gap: '8px' } },
        [
          h(
            'button',
            {
              className: 'gridjs-button gridjs-button--edit',
              onClick: () => {
                const staffMember = staff.find((s) => s._id === row.cells[0].data);
                setSelectedStaff(staffMember);
                onOpen();
              },
              style: {
                backgroundColor: '#1a73e8', // Brand color matching Chakra's brand.500
                color: 'white',
                borderRadius: '12px',
                padding: '4px 12px',
                border: 'none',
                cursor: 'pointer',
                fontSize: '14px',
                transition: 'transform 0.2s, box-shadow 0.2s',
              },
              onMouseEnter: (e) => {
                e.target.style.transform = 'translateY(-2px)';
                e.target.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
              },
              onMouseLeave: (e) => {
                e.target.style.transform = 'translateY(0)';
                e.target.style.boxShadow = 'none';
              },
            },
            'Edit'
          ),
          h(
            'button',
            {
              className: 'gridjs-button gridjs-button--delete',
              onClick: () => handleDelete(row.cells[0].data),
              style: {
                backgroundColor: '#e53e3e', // Red color matching Chakra's red
                color: 'white',
                borderRadius: '12px',
                padding: '4px 12px',
                border: 'none',
                cursor: 'pointer',
                fontSize: '14px',
                transition: 'transform 0.2s, box-shadow 0.2s',
              },
              onMouseEnter: (e) => {
                e.target.style.transform = 'translateY(-2px)';
                e.target.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
              },
              onMouseLeave: (e) => {
                e.target.style.transform = 'translateY(0)';
                e.target.style.boxShadow = 'none';
              },
            },
            'Delete'
          ),
        ]
      ),
      data: (row) => row._id, // Pass _id for the formatter
    },
  ];

  return (
    <Flex h="100vh" direction={{ base: 'column', md: 'row' }}>
      <Box
        display={{
          base: isSidebarOpen ? 'block' : 'none',
          md: 'block',
        }}
        position={{ base: 'absolute', md: 'fixed' }}
        zIndex={20}
        w={{ base: '250px', md: '250px' }}
        h={{ base: '100vh', md: '100vh' }}
      >
        <Sidebar />
      </Box>
      <Box
        flex="1"
        overflowY="auto"
        ml={{ base: 0, md: '250px' }}
      >
        <Navbar title="Staff" toggleSidebar={toggleSidebar} />
        <Box p="6" pt={0}>
          <Box mt={6}>
            <Button
              colorScheme="brand"
              borderRadius="12px"
              size="md"
              _hover={{ transform: 'translateY(-2px)', shadow: 'md' }}
              onClick={() => {
                setSelectedStaff(null);
                onOpen();
              }}
            >
              Create Staff
            </Button>
          </Box>
          <Box
            mt={6}
            shadow="lg"
            borderRadius="15px"
            overflow="hidden"
            bg="white"
          >
            <Grid
              data={staff}
              columns={columns}
              sort={true}
              pagination={{
                enabled: true,
                limit: 5,
              }}
              style={{
                table: {
                  border: 'none',
                },
                th: {
                  backgroundColor: '#f7fafc',
                  color: '#2d3748',
                  fontWeight: 'bold',
                  padding: '16px',
                },
                td: {
                  padding: '16px',
                  borderBottom: '1px solid #e2e8f0',
                },
                container: {
                  padding: '16px',
                },
              }}
              className={{
                table: 'w-full',
                pagination: 'mt-4 flex justify-end',
                paginationButton: 'px-3 py-1 mx-1 rounded-lg border',
                paginationButtonCurrent: 'bg-brand.500 text-white',
              }}
            />
          </Box>
          <StaffForm
            isOpen={isOpen}
            onClose={onClose}
            staff={selectedStaff}
            onSubmit={selectedStaff ? handleEdit : handleCreate}
          />
        </Box>
      </Box>
    </Flex>
  );
}

export default Staff;