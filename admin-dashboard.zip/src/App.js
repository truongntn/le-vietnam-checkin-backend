import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { ChakraProvider } from '@chakra-ui/react';
import theme from './theme';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Users from './pages/Users';
import CheckIns from './pages/CheckIns';
import Queue from './pages/Queue';
import Staff from './pages/Staff';
import Login from './pages/Login';

function App() {
  const [isSidebarOpen, setSidebarOpen] = useState(false);

  return (
    <ChakraProvider theme={theme}>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="*"
            element={
              <>
                <Navbar onOpen={() => setSidebarOpen(true)} />
                <Sidebar isOpen={isSidebarOpen} onClose={() => setSidebarOpen(false)} />
                <Routes>
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/users" element={<Users />} />
                  <Route path="/checkins" element={<CheckIns />} />
                  <Route path="/queues" element={<Queue />} />
                  <Route path="/staff" element={<Staff />} />
                  <Route path="/" element={<Dashboard />} />
                </Routes>
              </>
            }
          />
        </Routes>
      </Router>
    </ChakraProvider>
  );
}

export default App;