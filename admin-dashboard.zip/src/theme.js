import { extendTheme } from '@chakra-ui/react';

const theme = extendTheme({
  colors: {
    primary: {
      50: '#FFE7E0', // Lightest shade
      100: '#FFC2B3',
      200: '#FF9C85',
      300: '#FF7757',
      400: '#FF5129',
      500: '#F05122', // Main color
      600: '#C2411B',
      700: '#943114',
      800: '#65220E',
      900: '#361207', // Darkest shade
    },
  },
  components: {
    Button: {
      variants: {
        solid: {
          bg: 'primary.500',
          color: 'white',
          _hover: {
            bg: 'primary.600',
          },
        },
      },
    },
    Link: {
      baseStyle: {
        _hover: {
          color: 'primary.600',
        },
      },
    },
  },
});

export default theme;